
module.exports = {
  content: ["./pages/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        copper: {
          500: '#b87333',
          700: '#8a4b1a'
        }
      }
    }
  },
  plugins: []
}
